Full Name: <?php echo $first_name." ".$last_name?>
<br>Mailing Address : <?php echo $address?>
<br>City, State, Zip Code : <?php echo $city." ".$state." ".$zip_code ?>
<br>Phone Number : <?php echo $phone ?>
<br>Mobile Phone : <?php echo $mobile?>
<br>Email : <?php echo $emailAddress?>
<br>Occupation : <?php echo $occupation?>
<br>IP : <?php echo $ip?>